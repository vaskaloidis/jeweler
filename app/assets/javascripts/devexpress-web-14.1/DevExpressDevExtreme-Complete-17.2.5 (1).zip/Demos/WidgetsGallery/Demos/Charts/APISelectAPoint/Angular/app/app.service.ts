import { Injectable } from '@angular/core';

export class CatBreed {
    breed: string;
    count: number;
}

let catBreeds: CatBreed[] = [{
    breed: "Domestic Shorthair",
    count: 61046
}, {
    breed: "American Shorthair",
    count: 37545
}, {
    breed: "Domestic Medium Hair",
    count: 16776
}, {
    breed: "Domestic Long Hair",
    count: 15049
}, {
    breed: "Siamese",
    count: 14582
}, {
    breed: "Maine Coon",
    count: 10852
}, {
    breed: "Persian",
    count: 6717
}, {
    breed: "Russian Blue",
    count: 3864
}, {
    breed: "Himalayan",
    count: 3701
}, {
    breed: "Ragdoll",
    count: 3567
}, {
    breed: "Bengal",
    count: 3118
}, {
    breed: "Manx",
    count: 2349
}, {
    breed: "British Shorthair",
    count: 2171
}, {
    breed: "Norwegian Forest Cat",
    count: 1827
}, {
    breed: "Bombay",
    count: 1580
}];

@Injectable()
export class Service {
    getCatBreedsData(): CatBreed[] {
        return catBreeds;
    }
}