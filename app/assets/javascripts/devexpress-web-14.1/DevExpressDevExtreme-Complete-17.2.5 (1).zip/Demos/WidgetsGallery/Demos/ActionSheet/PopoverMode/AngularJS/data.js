var actionSheetItems = [
        { text: "Call" },
        { text: "Send message" },
        { text: "Edit" },
        { text: "Delete" }
];

var contacts = [
        { name: "Barbara J. Coggins", phone: "512-964-2757", email: "BarbaraJCoggins@rhyta.com", category: "Family" },
        { name: "Leslie S. Alcantara", phone: "360-684-1334", email: "LeslieSAlcantara@teleworm.us", category: "Friends" },
        { name: "Chad S. Miles", phone: "520-573-7903", email: "ChadSMiles@rhyta.com", category: "Work" },
        { name: "Michael A. Blevins", phone: "530-480-1961", email: "MichaelABlevins@armyspy.com", category: "Work" },
        { name: "Jane K. Hernandez", phone: "404-781-0805", email: "JaneKHernandez@teleworm.us", category: "Friends" },
        { name: "Kim D. Thomas", phone: "603-583-9043", email: "KimDThomas@teleworm.us", category: "Work" },
        { name: "Donald L. Jordan", phone: "772-766-2842", email: "DonaldLJordan@dayrep.com", category: "Family" },
        { name: "Nicole A. Rios", phone: "213-812-8400", email: "NicoleARios@armyspy.com", category: "Friends" },
        { name: "Barbara M. Roberts", phone: "614-365-7945", email: "BarbaraMRoberts@armyspy.com", category: "Friends" }       
];