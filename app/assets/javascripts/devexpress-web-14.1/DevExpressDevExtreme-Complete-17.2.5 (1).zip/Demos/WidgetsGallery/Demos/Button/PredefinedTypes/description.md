This demo illustrates the predefined types of&nbsp;the **Button** widget. A&nbsp;[Toast][0] is&nbsp;displayed each time you click a&nbsp;**Button**.

[0]: https://js.devexpress.com/Documentation/Guide/Widgets/Toast/Overview/